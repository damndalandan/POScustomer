import { supabase } from '@/lib/supabase'
import { User } from '@/types'

export async function login(
  username: string,
  password: string
): Promise<{ user: User | null; error: string | null }> {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('username', username)
      .eq('password_hash', password)
      .eq('is_active', true)
      .single()

    if (error || !data) {
      return { user: null, error: 'Invalid username or password' }
    }

    localStorage.setItem('chiara_user', JSON.stringify(data))
    return { user: data, error: null }
  } catch {
    return { user: null, error: 'Something went wrong. Please try again.' }
  }
}

export function logout() {
  localStorage.removeItem('chiara_user')
  window.location.href = '/login'
}

export function getStoredUser(): User | null {
  if (typeof window === 'undefined') return null
  const stored = localStorage.getItem('chiara_user')
  if (!stored) return null
  try {
    return JSON.parse(stored) as User
  } catch {
    return null
  }
}

export function isAuthenticated(): boolean {
  return getStoredUser() !== null
}

export function isAdmin(): boolean {
  const user = getStoredUser()
  return user?.role === 'admin'
}
