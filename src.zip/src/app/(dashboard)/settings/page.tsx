'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { getStoredUser } from '@/lib/auth'
import { StoreSettings } from '@/types'

export default function SettingsPage() {
  const user = getStoredUser()
  const [settings, setSettings] = useState<StoreSettings | null>(null)
  const [form, setForm] = useState({ store_name: '', address: '', phone: '', receipt_footer: '', low_stock_default: '5' })
  const [pwForm, setPwForm] = useState({ current: '', newPw: '', confirm: '' })
  const [toast, setToast] = useState('')
  const [newUser, setNewUser] = useState({ username: '', password: '', full_name: '', role: 'cashier' })
  const [users, setUsers] = useState<Record<string, unknown>[]>([])

  useEffect(() => { loadData() }, [])

  async function loadData() {
    const { data: s } = await supabase.from('store_settings').select('*').single()
    if (s) {
      setSettings(s)
      setForm({
        store_name: s.store_name || '',
        address: s.address || '',
        phone: s.phone || '',
        receipt_footer: s.receipt_footer || '',
        low_stock_default: s.low_stock_default?.toString() || '5',
      })
    }
    const { data: u } = await supabase.from('users').select('id, username, role, full_name, is_active').order('created_at')
    if (u) setUsers(u)
  }

  function showToast(msg: string) {
    setToast(msg)
    setTimeout(() => setToast(''), 2500)
  }

  async function saveSettings() {
    if (!settings) return
    const { error } = await supabase.from('store_settings').update({
      store_name: form.store_name,
      address: form.address || null,
      phone: form.phone || null,
      receipt_footer: form.receipt_footer || null,
      low_stock_default: parseInt(form.low_stock_default) || 5,
    }).eq('id', settings.id)
    if (error) { showToast('❌ Error saving settings'); return }
    showToast('✅ Settings saved!')
  }

  async function changePassword() {
    if (!pwForm.newPw || pwForm.newPw !== pwForm.confirm) {
      showToast('⚠️ Passwords do not match!')
      return
    }
    const { error } = await supabase.from('users').update({ password_hash: pwForm.newPw }).eq('id', user?.id)
    if (error) { showToast('❌ Error changing password'); return }
    showToast('✅ Password changed!')
    setPwForm({ current: '', newPw: '', confirm: '' })
  }

  async function addUser() {
    if (!newUser.username || !newUser.password) {
      showToast('⚠️ Username and password required!')
      return
    }
    const { error } = await supabase.from('users').insert({
      username: newUser.username,
      password_hash: newUser.password,
      role: newUser.role,
      full_name: newUser.full_name || null,
    })
    if (error) { showToast('❌ Username already exists!'); return }
    showToast('✅ User added!')
    setNewUser({ username: '', password: '', full_name: '', role: 'cashier' })
    loadData()
  }

  async function toggleUser(id: string, active: boolean) {
    await supabase.from('users').update({ is_active: !active }).eq('id', id)
    loadData()
  }

  return (
    <div style={{ height: '100%', overflowY: 'auto' }}>
      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl text-white text-sm shadow-lg" style={{ backgroundColor: '#3d2c2c' }}>
          {toast}
        </div>
      )}

      <div className="p-4 space-y-4">
        {/* Store Settings */}
        <div className="bg-white rounded-2xl p-4" style={{ border: '1px solid #e8ddd9' }}>
          <p className="font-semibold text-sm mb-4" style={{ color: '#3d2c2c' }}>🏪 Store Settings</p>
          <div className="space-y-3">
            {[
              { label: 'STORE NAME', key: 'store_name', type: 'text', placeholder: 'Chiara Store' },
              { label: 'ADDRESS', key: 'address', type: 'text', placeholder: 'Store address' },
              { label: 'PHONE', key: 'phone', type: 'text', placeholder: '09XX XXX XXXX' },
              { label: 'RECEIPT FOOTER', key: 'receipt_footer', type: 'text', placeholder: 'Thank you!' },
              { label: 'DEFAULT LOW STOCK THRESHOLD', key: 'low_stock_default', type: 'number', placeholder: '5' },
            ].map(f => (
              <div key={f.key}>
                <label className="text-xs font-medium tracking-wide block mb-1" style={{ color: '#9e8585' }}>{f.label}</label>
                <input
                  type={f.type}
                  placeholder={f.placeholder}
                  value={form[f.key as keyof typeof form]}
                  onChange={e => setForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                  className="w-full px-4 py-2.5 rounded-xl text-sm outline-none"
                  style={{ backgroundColor: '#f5f0ee', border: '1.5px solid #e8ddd9', color: '#3d2c2c' }}
                />
              </div>
            ))}
          </div>
          <button onClick={saveSettings} className="w-full mt-4 py-3 rounded-xl text-sm font-bold text-white" style={{ background: 'linear-gradient(135deg, #c4a09a, #b08a8a)' }}>
            Save Settings
          </button>
        </div>

        {/* Change Password */}
        <div className="bg-white rounded-2xl p-4" style={{ border: '1px solid #e8ddd9' }}>
          <p className="font-semibold text-sm mb-4" style={{ color: '#3d2c2c' }}>🔒 Change Password</p>
          <div className="space-y-3">
            {[
              { label: 'NEW PASSWORD', key: 'newPw', placeholder: 'New password' },
              { label: 'CONFIRM PASSWORD', key: 'confirm', placeholder: 'Confirm password' },
            ].map(f => (
              <div key={f.key}>
                <label className="text-xs font-medium tracking-wide block mb-1" style={{ color: '#9e8585' }}>{f.label}</label>
                <input
                  type="password"
                  placeholder={f.placeholder}
                  value={pwForm[f.key as keyof typeof pwForm]}
                  onChange={e => setPwForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                  className="w-full px-4 py-2.5 rounded-xl text-sm outline-none"
                  style={{ backgroundColor: '#f5f0ee', border: '1.5px solid #e8ddd9', color: '#3d2c2c' }}
                />
              </div>
            ))}
          </div>
          <button onClick={changePassword} className="w-full mt-4 py-3 rounded-xl text-sm font-bold text-white" style={{ background: 'linear-gradient(135deg, #c4a09a, #b08a8a)' }}>
            Change Password
          </button>
        </div>

        {/* User Management */}
        <div className="bg-white rounded-2xl p-4" style={{ border: '1px solid #e8ddd9' }}>
          <p className="font-semibold text-sm mb-4" style={{ color: '#3d2c2c' }}>👥 User Management</p>

          {/* Existing users */}
          <div className="space-y-2 mb-4">
            {users.map(u => (
              <div key={u.id as string} className="flex items-center justify-between p-3 rounded-xl" style={{ backgroundColor: '#f5f0ee' }}>
                <div>
                  <p className="text-sm font-medium" style={{ color: '#3d2c2c' }}>{u.username as string}</p>
                  <p className="text-xs" style={{ color: '#9e8585' }}>
                    {u.role as string} {u.full_name ? `· ${u.full_name}` : ''}
                  </p>
                </div>
                {(u.id as string) !== user?.id && (
                  <button
                    onClick={() => toggleUser(u.id as string, u.is_active as boolean)}
                    className="text-xs px-3 py-1.5 rounded-lg"
                    style={{
                      backgroundColor: (u.is_active as boolean) ? '#f9e8e8' : '#e8f5e8',
                      color: (u.is_active as boolean) ? '#c47a7a' : '#7aaa7a',
                    }}
                  >
                    {(u.is_active as boolean) ? 'Disable' : 'Enable'}
                  </button>
                )}
              </div>
            ))}
          </div>

          {/* Add new user */}
          <p className="text-xs font-medium mb-2" style={{ color: '#9e8585' }}>ADD NEW USER</p>
          <div className="space-y-2">
            {[
              { label: 'Full Name', key: 'full_name', type: 'text', placeholder: 'Full name' },
              { label: 'Username', key: 'username', type: 'text', placeholder: 'Username' },
              { label: 'Password', key: 'password', type: 'password', placeholder: 'Password' },
            ].map(f => (
              <input
                key={f.key}
                type={f.type}
                placeholder={f.placeholder}
                value={newUser[f.key as keyof typeof newUser]}
                onChange={e => setNewUser(prev => ({ ...prev, [f.key]: e.target.value }))}
                className="w-full px-4 py-2.5 rounded-xl text-sm outline-none"
                style={{ backgroundColor: '#f5f0ee', border: '1.5px solid #e8ddd9', color: '#3d2c2c' }}
              />
            ))}
            <select
              value={newUser.role}
              onChange={e => setNewUser(prev => ({ ...prev, role: e.target.value }))}
              className="w-full px-4 py-2.5 rounded-xl text-sm outline-none"
              style={{ backgroundColor: '#f5f0ee', border: '1.5px solid #e8ddd9', color: '#3d2c2c' }}
            >
              <option value="cashier">Cashier</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          <button onClick={addUser} className="w-full mt-3 py-3 rounded-xl text-sm font-bold text-white" style={{ background: 'linear-gradient(135deg, #c4a09a, #b08a8a)' }}>
            + Add User
          </button>
        </div>

        {/* App info */}
        <div className="text-center py-4" style={{ color: '#9e8585' }}>
          <p className="text-xs">Chiara Store POS v1.0</p>
          <p className="text-xs mt-1">Built with Next.js + Supabase</p>
        </div>
      </div>
    </div>
  )
}
