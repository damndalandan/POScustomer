'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { Utang } from '@/types'
import { getStoredUser } from '@/lib/auth'

export default function UtangPage() {
  const [utangs, setUtangs] = useState<Utang[]>([])
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState<'all' | 'unpaid' | 'partial' | 'paid'>('unpaid')
  const [showForm, setShowForm] = useState(false)
  const [showPayment, setShowPayment] = useState(false)
  const [selectedUtang, setSelectedUtang] = useState<Utang | null>(null)
  const [toast, setToast] = useState('')
  const [form, setForm] = useState({ customer_name: '', amount: '', notes: '' })
  const [payment, setPayment] = useState({ amount: '', method: 'cash', gcash_ref: '' })
  const user = getStoredUser()

  useEffect(() => { loadData() }, [])

  async function loadData() {
    const { data } = await supabase.from('utang').select('*').order('created_at', { ascending: false })
    if (data) setUtangs(data)
  }

  function showToast(msg: string) {
    setToast(msg)
    setTimeout(() => setToast(''), 2500)
  }

  async function handleAddUtang() {
    if (!form.customer_name || !form.amount) {
      showToast('⚠️ Customer name and amount required!')
      return
    }
    const { error } = await supabase.from('utang').insert({
      customer_name: form.customer_name,
      total_amount: parseFloat(form.amount),
      paid_amount: 0,
      status: 'unpaid',
      notes: form.notes || null,
      created_by: user?.id || null,
    })
    if (error) { showToast('❌ Error saving utang'); return }
    showToast('✅ Utang recorded!')
    setShowForm(false)
    setForm({ customer_name: '', amount: '', notes: '' })
    loadData()
  }

  async function handlePayment() {
    if (!selectedUtang || !payment.amount) {
      showToast('⚠️ Enter payment amount!')
      return
    }
    const amt = parseFloat(payment.amount)
    const newPaid = selectedUtang.paid_amount + amt
    const status = newPaid >= selectedUtang.total_amount ? 'paid' : 'partial'

    const { error } = await supabase.from('utang_payments').insert({
      utang_id: selectedUtang.id,
      amount: amt,
      payment_method: payment.method,
      gcash_reference: payment.method === 'gcash' ? payment.gcash_ref : null,
      received_by: user?.id || null,
    })
    if (error) { showToast('❌ Error recording payment'); return }

    await supabase.from('utang').update({ paid_amount: newPaid, status }).eq('id', selectedUtang.id)
    showToast('✅ Payment recorded!')
    setShowPayment(false)
    setPayment({ amount: '', method: 'cash', gcash_ref: '' })
    loadData()
  }

  const filtered = utangs.filter(u => {
    const matchSearch = u.customer_name.toLowerCase().includes(search.toLowerCase())
    const matchFilter = filter === 'all' || u.status === filter
    return matchSearch && matchFilter
  })

  const totalUnpaid = utangs.filter(u => u.status !== 'paid').reduce((s, u) => s + u.balance, 0)

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl text-white text-sm shadow-lg" style={{ backgroundColor: '#3d2c2c' }}>
          {toast}
        </div>
      )}

      {/* Header */}
      <div className="p-4" style={{ backgroundColor: '#f5f0ee' }}>
        {/* Summary */}
        <div className="rounded-xl p-3 mb-3 flex justify-between items-center" style={{ backgroundColor: '#fdf0f0', border: '1px solid #f5c4c4' }}>
          <div>
            <p className="text-xs" style={{ color: '#c47a7a' }}>Total Outstanding</p>
            <p className="text-xl font-bold" style={{ color: '#c47a7a' }}>₱{totalUnpaid.toFixed(2)}</p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="px-4 py-2 rounded-xl text-sm font-semibold text-white"
            style={{ background: 'linear-gradient(135deg, #c4a09a, #b08a8a)' }}
          >
            + Add Utang
          </button>
        </div>

        <input
          type="text"
          placeholder="🔍 Search customer..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full px-4 py-2.5 rounded-xl text-sm outline-none mb-3"
          style={{ backgroundColor: '#fff', border: '1.5px solid #e8ddd9', color: '#3d2c2c' }}
        />

        <div className="flex gap-2 overflow-x-auto pb-1">
          {(['unpaid', 'partial', 'paid', 'all'] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap"
              style={{
                backgroundColor: filter === f ? '#b08a8a' : '#e8ddd9',
                color: filter === f ? 'white' : '#9e8585',
              }}
            >
              {f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-2">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full" style={{ color: '#9e8585' }}>
            <p className="text-4xl mb-2">😊</p>
            <p className="text-sm">No utang records</p>
          </div>
        ) : (
          filtered.map(u => (
            <div key={u.id} className="bg-white rounded-2xl p-4" style={{ border: '1px solid #e8ddd9' }}>
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-semibold text-sm" style={{ color: '#3d2c2c' }}>{u.customer_name}</p>
                  <p className="text-xs mt-0.5" style={{ color: '#9e8585' }}>
                    {new Date(u.created_at).toLocaleDateString('en-PH')}
                  </p>
                </div>
                <span
                  className="text-xs px-2 py-1 rounded-lg font-medium"
                  style={{
                    backgroundColor: u.status === 'paid' ? '#f0f9f0' : u.status === 'partial' ? '#fdf5f0' : '#fdf0f0',
                    color: u.status === 'paid' ? '#7aaa7a' : u.status === 'partial' ? '#c4aa7a' : '#c47a7a',
                  }}
                >
                  {u.status}
                </span>
              </div>

              <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                <div className="rounded-lg p-2" style={{ backgroundColor: '#f5f0ee' }}>
                  <p className="text-xs" style={{ color: '#9e8585' }}>Total</p>
                  <p className="text-sm font-bold" style={{ color: '#3d2c2c' }}>₱{u.total_amount.toFixed(2)}</p>
                </div>
                <div className="rounded-lg p-2" style={{ backgroundColor: '#f0f9f0' }}>
                  <p className="text-xs" style={{ color: '#9e8585' }}>Paid</p>
                  <p className="text-sm font-bold" style={{ color: '#7aaa7a' }}>₱{u.paid_amount.toFixed(2)}</p>
                </div>
                <div className="rounded-lg p-2" style={{ backgroundColor: '#fdf0f0' }}>
                  <p className="text-xs" style={{ color: '#9e8585' }}>Balance</p>
                  <p className="text-sm font-bold" style={{ color: '#c47a7a' }}>₱{u.balance.toFixed(2)}</p>
                </div>
              </div>

              {u.status !== 'paid' && (
                <button
                  onClick={() => { setSelectedUtang(u); setShowPayment(true) }}
                  className="w-full mt-3 py-2.5 rounded-xl text-sm font-semibold text-white"
                  style={{ background: 'linear-gradient(135deg, #c4a09a, #b08a8a)' }}
                >
                  💵 Record Payment
                </button>
              )}
            </div>
          ))
        )}
      </div>

      {/* Add Utang Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="w-full max-w-sm rounded-3xl p-5 shadow-xl" style={{ backgroundColor: '#fff' }}>
            <h3 className="font-bold text-base mb-4" style={{ color: '#3d2c2c' }}>😬 New Utang</h3>
            <div className="space-y-3">
              {[
                { label: 'CUSTOMER NAME *', key: 'customer_name', type: 'text', placeholder: 'e.g. Maria Santos' },
                { label: 'AMOUNT (₱) *', key: 'amount', type: 'number', placeholder: '0.00' },
                { label: 'NOTES (optional)', key: 'notes', type: 'text', placeholder: 'e.g. Rice and canned goods' },
              ].map(f => (
                <div key={f.key}>
                  <label className="text-xs font-medium tracking-wide block mb-1" style={{ color: '#9e8585' }}>{f.label}</label>
                  <input
                    type={f.type}
                    placeholder={f.placeholder}
                    value={form[f.key as keyof typeof form]}
                    onChange={e => setForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                    className="w-full px-4 py-3 rounded-xl text-sm outline-none"
                    style={{ backgroundColor: '#f5f0ee', border: '1.5px solid #e8ddd9', color: '#3d2c2c' }}
                  />
                </div>
              ))}
            </div>
            <div className="flex gap-2 mt-5">
              <button onClick={() => setShowForm(false)} className="flex-1 py-3 rounded-xl text-sm font-semibold" style={{ backgroundColor: '#f5f0ee', color: '#9e8585' }}>Cancel</button>
              <button onClick={handleAddUtang} className="flex-1 py-3 rounded-xl text-sm font-bold text-white" style={{ background: 'linear-gradient(135deg, #c4a09a, #b08a8a)' }}>Save Utang</button>
            </div>
          </div>
        </div>
      )}

      {/* Payment Modal */}
      {showPayment && selectedUtang && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="w-full max-w-sm rounded-3xl p-5 shadow-xl" style={{ backgroundColor: '#fff' }}>
            <h3 className="font-bold text-base mb-1" style={{ color: '#3d2c2c' }}>💵 Record Payment</h3>
            <p className="text-sm mb-4" style={{ color: '#9e8585' }}>{selectedUtang.customer_name}</p>
            <div className="rounded-xl p-3 mb-4 flex justify-between" style={{ backgroundColor: '#fdf0f0' }}>
              <span className="text-sm" style={{ color: '#9e8585' }}>Balance</span>
              <span className="text-sm font-bold" style={{ color: '#c47a7a' }}>₱{selectedUtang.balance.toFixed(2)}</span>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs font-medium tracking-wide block mb-1" style={{ color: '#9e8585' }}>AMOUNT *</label>
                <input type="number" placeholder="0.00" value={payment.amount} onChange={e => setPayment(p => ({ ...p, amount: e.target.value }))}
                  className="w-full px-4 py-3 rounded-xl text-sm outline-none" style={{ backgroundColor: '#f5f0ee', border: '1.5px solid #e8ddd9', color: '#3d2c2c' }} />
              </div>
              <div className="flex gap-2">
                {(['cash', 'gcash'] as const).map(m => (
                  <button key={m} onClick={() => setPayment(p => ({ ...p, method: m }))}
                    className="flex-1 py-2.5 rounded-xl text-sm font-semibold"
                    style={{ backgroundColor: payment.method === m ? '#b08a8a' : '#f5f0ee', color: payment.method === m ? 'white' : '#9e8585' }}>
                    {m === 'cash' ? '💵 Cash' : '📱 GCash'}
                  </button>
                ))}
              </div>
              {payment.method === 'gcash' && (
                <div>
                  <label className="text-xs font-medium tracking-wide block mb-1" style={{ color: '#9e8585' }}>GCASH REF NO.</label>
                  <input type="text" placeholder="Reference number" value={payment.gcash_ref} onChange={e => setPayment(p => ({ ...p, gcash_ref: e.target.value }))}
                    className="w-full px-4 py-3 rounded-xl text-sm outline-none" style={{ backgroundColor: '#f5f0ee', border: '1.5px solid #e8ddd9', color: '#3d2c2c' }} />
                </div>
              )}
            </div>
            <div className="flex gap-2 mt-5">
              <button onClick={() => setShowPayment(false)} className="flex-1 py-3 rounded-xl text-sm font-semibold" style={{ backgroundColor: '#f5f0ee', color: '#9e8585' }}>Cancel</button>
              <button onClick={handlePayment} className="flex-1 py-3 rounded-xl text-sm font-bold text-white" style={{ background: 'linear-gradient(135deg, #c4a09a, #b08a8a)' }}>✅ Confirm</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
